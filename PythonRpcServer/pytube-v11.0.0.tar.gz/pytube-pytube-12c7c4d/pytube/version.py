__version__ = "11.0.0"

if __name__ == "__main__":
    print(__version__)
